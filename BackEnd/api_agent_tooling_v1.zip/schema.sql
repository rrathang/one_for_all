CREATE TABLE IF NOT EXISTS api_container (
  id INT AUTO_INCREMENT PRIMARY KEY,
  api_def LONGTEXT NOT NULL,
  description VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS call_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  function_id INT NOT NULL,
  success TINYINT(1) NOT NULL,
  latency_ms INT NOT NULL,
  error_message VARCHAR(500) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fn_time (function_id, created_at),
  CONSTRAINT fk_fn FOREIGN KEY (function_id) REFERENCES api_container(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Base tables you already created (kept for reference)
-- api_container & call_logs per your schema

-- Extra columns for ownership & visibility
ALTER TABLE api_container
  ADD COLUMN owner_id INT NOT NULL DEFAULT 0 AFTER description;

ALTER TABLE api_container
  ADD COLUMN visibility ENUM('private','public') NOT NULL DEFAULT 'private' AFTER owner_id;

-- Users table for auth
CREATE TABLE IF NOT EXISTS users (
  id INT AUTusersO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed a user (replace the hash)
-- INSERT INTO users (email, name, password_hash) VALUES ('you@example.com', 'You', '<paste_hash_here>');
