
// ===================== GLOBAL =====================
const API_BASE = '';
let AUTH_TOKEN = localStorage.getItem('ss_token') || null;
let CURRENT_USER = null;
let editor;
let currentDraftId = null;

// ===================== BASIC HELPERS =====================
async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (AUTH_TOKEN) headers['Authorization'] = `Bearer ${AUTH_TOKEN}`;
  const res = await fetch(API_BASE + path, { ...options, headers });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function getEditorValue() {
  return editor ? editor.getValue() : document.getElementById('codeEditor').value;
}

// Robust toast system
function showToast(title, message, type = "info") {
  const colors = {
    success: "bg-success text-white",
    danger: "bg-danger text-white",
    warning: "bg-warning text-dark",
    info: "bg-info text-dark"
  };
  const cls = colors[type] || colors.info;

  const toastArea = document.getElementById("toastArea") || document.body;
  const toastId = "toast_" + Date.now();

  // Build toast HTML
  const toast = document.createElement("div");
  toast.className = `toast align-items-center border-0 ${cls}`;
  toast.id = toastId;
  toast.role = "alert";
  toast.ariaLive = "assertive";
  toast.ariaAtomic = "true";
  toast.innerHTML = `
    <div class="d-flex">
      <div class="toast-body fw-semibold">
        <i class="bi bi-info-circle-fill me-2"></i><strong>${title}</strong>: ${message}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  `;
  toastArea.appendChild(toast);

  // Initialize & show using Bootstrap’s API
  const bsToast = new bootstrap.Toast(toast, { delay: 4000 });
  bsToast.show();

  // Auto-remove after hidden
  toast.addEventListener("hidden.bs.toast", () => toast.remove());
}

function safeJSONParse(text, fallback = {}) {
  try { return JSON.parse(text); } catch { return fallback; }
}

// ===================== INITIALIZATION =====================
document.addEventListener('DOMContentLoaded', () => {
  // Init CodeMirror
  const el = document.getElementById('codeEditor');
  if (el) {
    editor = CodeMirror.fromTextArea(el, {
      mode: 'python', theme: 'dracula', lineNumbers: true, autoCloseBrackets: true, indentUnit: 4
    });
  }

  // Button bindings
  const btnSave = document.getElementById('btnSaveDraft');
  const btnTest = document.getElementById('btnDraftTest');
  const btnPromote = document.getElementById('btnPromote');
  if (btnSave) btnSave.addEventListener('click', onSaveDraft);
  if (btnTest) btnTest.addEventListener('click', onTestDraft);
  if (btnPromote) btnPromote.addEventListener('click', onPromoteDraft);
});

// ===================== NAVIGATION =====================

// Utility to switch visible section
function setSection(targetId) {
  // Hide all sections
  document.querySelectorAll("section").forEach((sec) => sec.classList.add("d-none"));
  // Show selected section
  const target = document.getElementById(targetId);
  if (target) target.classList.remove("d-none");

  // Update active state on nav links
  document.querySelectorAll(".nav-link").forEach((a) => a.classList.remove("active"));
  document
    .querySelectorAll(`[data-target='${targetId}']`)
    .forEach((a) => a.classList.add("active"));
}

// Attach event listeners to sidebar and top tabs
document.addEventListener("DOMContentLoaded", () => {
  const nav = document.getElementById("sideNav");
  if (nav) {
    nav.addEventListener("click", (e) => {
      const link = e.target.closest("a[data-target]");
      if (!link) return;
      e.preventDefault();
      const target = link.dataset.target;
      setSection(target);
    });
  }

  const tabs = document.getElementById("topTabs");
  if (tabs) {
    tabs.addEventListener("click", (e) => {
      const link = e.target.closest("a[data-target]");
      if (!link) return;
      e.preventDefault();
      const target = link.dataset.target;
      setSection(target);
    });
  }
});


// ===================== DRAFT API =====================
async function saveDraft(desc, code, visibility, draftId) {
  const body = { description: desc, code, visibility };
  if (draftId) body.id = draftId;
  return api('/drafts', { method: 'POST', body: JSON.stringify(body) });
}

async function testDraftAPI(draftId, args) {
  return api(`/drafts/${draftId}:test`, { method: 'POST', body: JSON.stringify({ args }) });
}

async function promoteDraftAPI(draftId) {
  return api(`/drafts/${draftId}:promote`, { method: 'POST' });
}

// ===================== UI HANDLERS =====================
async function onSaveDraft() {
  console.log("onSaveDraft")
  const desc = document.getElementById('functionDesc').value.trim();
  const code = getEditorValue();
  const visibility = document.getElementById('functionVisibility').value;

  if (!desc) return showToast('Draft', 'Please add a description.', 'warning');
  if (!code.includes('def api_def')) return showToast('Draft', "Your code must define 'def api_def(args): ...'", 'warning');

  try {
    const res = await saveDraft(desc, code, visibility, currentDraftId);
    if (res.error) throw new Error(res.error);
    currentDraftId = res.id;
    const label = document.getElementById('currentDraftId');
    if (label) label.textContent = currentDraftId;
    showToast('Draft', `Saved draft #${currentDraftId}`, 'success');
  } catch (err) {
    showToast('Draft', err.message || 'Failed to save draft', 'danger');
  }
}

async function onTestDraft() {
  if (!currentDraftId)
    return showToast('Test', 'Please save the draft first.', 'warning');

  const args = safeJSONParse(document.getElementById('testParams').value, {});
  document.getElementById('outputBox').textContent = '⏳ Testing draft...';

  try {
    const res = await api(`/drafts/${currentDraftId}:test`, {
      method: 'POST',
      body: JSON.stringify({ args }),
    });

    if (res.error) {
      showToast('Test', res.error, 'danger');
      document.getElementById('outputBox').textContent = JSON.stringify(res, null, 2);
    } else {
      showToast('Test', 'Draft executed successfully.', 'success');
      document.getElementById('outputBox').textContent = JSON.stringify(res, null, 2);
    }
  } catch (e) {
    showToast('Test', e.message || 'Error during test.', 'danger');
    document.getElementById('outputBox').textContent = e.message;
  }
}


async function onPromoteDraft() {
  if (!currentDraftId) return showToast('Promote', 'No draft to promote.', 'warning');
  try {
    const res = await promoteDraftAPI(currentDraftId);
    if (res.error) throw new Error(res.error);
    showToast('Promote', `Draft #${currentDraftId} promoted to prod #${res.id}`, 'success');
  } catch (e) {
    showToast('Promote', e.message || 'Promotion failed', 'danger');
  }
}
